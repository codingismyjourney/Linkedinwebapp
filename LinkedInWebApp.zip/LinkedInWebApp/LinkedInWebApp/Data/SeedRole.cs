﻿using LinkedInWebApp.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace LinkedInWebApp.Data;

public static class SeedRole
{
    public static async Task SeedRoles(RoleManager<AppRole> roleManager)
    {
        if (await roleManager.Roles.AnyAsync()) return;

        var roles = new List<AppRole>
        {
            new AppRole{Name = "Student"},
            new AppRole{Name = "CEO"},
            new AppRole{Name = "Manager"},
            new AppRole{Name = "Developer"},
            new AppRole{Name = "Designer"},
        };

        foreach (var role in roles)
        {
            await roleManager.CreateAsync(role);
        }
    }
}
