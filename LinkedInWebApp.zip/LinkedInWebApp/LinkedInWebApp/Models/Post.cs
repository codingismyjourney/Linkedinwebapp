﻿namespace LinkedInWebApp.Models;

public class Post
{
    public int Id { get; set; }
    public string Description { get; set; }
    public string Images { get; set; }
    public DateTime CreatedOn { get; set; }
    public DateTime ModifiedOn { get; set; }
    public int AppUserId { get; set; }
    public AppUser AppUser { get; set; }
    public ICollection<PostLike> PostLikes { get; set; }
    public ICollection<PostComment> PostComments { get; set; }
}
