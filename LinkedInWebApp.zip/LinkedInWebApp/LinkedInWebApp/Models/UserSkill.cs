﻿namespace LinkedInWebApp.Models;

public class UserSkill
{
    public int AppUserId { get; set; }
    public AppUser AppUser { get; set; }
    public int SkillId { get; set; }
    public Skill Skill { get; set; }
}
