﻿using Microsoft.AspNetCore.Identity;

namespace LinkedInWebApp.Models
{
    public class AppRole : IdentityRole<int>
    {
    }
}
