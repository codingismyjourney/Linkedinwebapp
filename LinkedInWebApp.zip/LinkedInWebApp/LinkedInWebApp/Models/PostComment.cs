﻿namespace LinkedInWebApp.Models;

public class PostComment
{
    public int Id { get; set; }
    public int AppUserId { get; set; }
    public AppUser AppUser { get; set; }
    public int PostId { get; set; }
    public Post Post { get; set; }
    public string Comment { get; set; }
    public DateTime CommentedOn { get; set; }
}
