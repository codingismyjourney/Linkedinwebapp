﻿namespace LinkedInWebApp.Models.ViewModels;

public class PostViewModel
{
    public string Description { get; set; }
    public IFormFile Image { get; set; }
}
