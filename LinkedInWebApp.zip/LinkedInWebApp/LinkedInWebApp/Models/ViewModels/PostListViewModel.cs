﻿namespace LinkedInWebApp.Models.ViewModels;

public class PostListViewModel
{
    public int Id { get; set; }
    public string Description { get; set; }
    public string Image { get; set; }
    public DateTime DateTime { get; set; }
    public string FullName { get; set; }
    public int Likes { get; set; }
    public List<CommentViewModel> Comments { get; set; }
    public string Username { get; set; }
    public bool UserLiked { get; set; }
}
