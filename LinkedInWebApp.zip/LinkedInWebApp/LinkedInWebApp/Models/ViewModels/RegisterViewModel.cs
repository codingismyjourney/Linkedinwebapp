﻿using System.ComponentModel.DataAnnotations;

namespace LinkedInWebApp.Models.ViewModels;
public class RegisterViewModel
{
    [Required]
    [Display(Name = "First Name")]
    public string FirstName { get; set; }

    [Required]
    [Display(Name = "Last Name")]
    public string LastName { get; set; }

    [Required]
    public string Gender { get; set; }

    [Required]
    [DataType(DataType.Password)]
    public string Password { get; set; }

    [Required]
    [DataType(DataType.EmailAddress)]
    [Display(Name = "Email Address")]
    public string Email { get; set; }

    [Display(Name = "Phone Number")]
    public string PhoneNumber { get; set; }

    [Display(Name = "Skills")]
    public List<int> SelectedSkills { get; set; } = new List<int>();

    [Required]
    [Display(Name = "Role")]
    public int SelectedRole { get; set; }
    public List<AppRole> AppRoles { get; set; }
    public List<Skill> Skills { get; set; }
}
