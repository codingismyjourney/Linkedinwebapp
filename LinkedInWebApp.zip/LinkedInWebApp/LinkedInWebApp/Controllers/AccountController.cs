﻿using LinkedInWebApp.Data;
using LinkedInWebApp.Models;
using LinkedInWebApp.Models.ViewModels;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LinkedInWebApp.Controllers
{
    public class AccountController : Controller
    {
        private readonly UserManager<AppUser> _userManager;
        private readonly SignInManager<AppUser> _signInManager;
        private readonly RoleManager<AppRole> _roleManager;
        private readonly DataContext _context;

        public AccountController(UserManager<AppUser> userManager,
                                 SignInManager<AppUser> signInManager,
                                 RoleManager<AppRole> roleManager,
                                 DataContext context)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _roleManager = roleManager;
            _context = context;
        }

        public async Task<IActionResult> Register()
        {
            var registerViewModel = new RegisterViewModel
            {
                Skills = await _context.Skills.ToListAsync(),
                AppRoles = await _roleManager.Roles.ToListAsync()
            };
            return View(registerViewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
                var user = new AppUser
                {
                    UserName = model.Email,
                    FirstName = model.FirstName,
                    LastName = model.LastName,
                    Email = model.Email,
                    PhoneNumber = model.PhoneNumber,
                    Gender = model.Gender,
                };

                var result = await _userManager.CreateAsync(user, model.Password);

                if (result.Succeeded)
                {

                    if (model.SelectedSkills != null)
                    {
                        var skills = model.SelectedSkills.Select(skillId => new UserSkill { SkillId = skillId, AppUserId = user.Id }).ToList();
                        await _context.UserSkills.AddRangeAsync(skills);
                    }

                    if (model.SelectedRole != 0)
                    {
                        var selectedRole = _context.Roles.Find(model.SelectedRole);
                        if (selectedRole != null)
                        {
                            _context.UserRoles.Add(new AppUserRole
                            {
                                UserId = user.Id,
                                RoleId = selectedRole.Id
                            });
                        }
                    }

                    await _context.SaveChangesAsync();
                    return RedirectToAction("Index", "Post");
                }
                else
                {
                    return View(model);
                }
            }

            return View(model);
        }


        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                var user = await _userManager.FindByEmailAsync(model.Email);

                if (user != null && await _userManager.CheckPasswordAsync(user, model.Password))
                {
                    var signInResult = await _signInManager.PasswordSignInAsync(user, model.Password, false, lockoutOnFailure: false);

                    if (signInResult.Succeeded)
                    {
                        return RedirectToAction("Index", "Post");
                    }
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Invalid login attempt.");
                }
            }

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Logout()
        {
            //await _signInManager.SignOutAsync();
            return RedirectToAction("Index", "Home");
        }
    }
}
