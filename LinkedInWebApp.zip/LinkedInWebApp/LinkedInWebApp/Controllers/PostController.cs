﻿using LinkedInWebApp.Data;
using LinkedInWebApp.Models;
using LinkedInWebApp.Models.ViewModels;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace LinkedInWebApp.Controllers
{
    public class PostController : Controller
    {
        private readonly DataContext _context;
        private readonly IHostEnvironment _environment;
        private readonly UserManager<AppUser> _userManager;

        public PostController(DataContext context, IHostEnvironment environment, UserManager<AppUser> userManager)
        {
            _context = context;
            _environment = environment;
            _userManager = userManager;
        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var posts = await _context.Posts
                                .Include(a => a.AppUser)
                                .Include(a => a.PostLikes)
                                .Include(a => a.PostComments)
                                .ToListAsync();

            var user = await GetCurrentUser(User);

            var postViewModel = posts.Select(post => new PostListViewModel
            {
                Id = post.Id,
                Description = post.Description,
                Image = "/images/" + post.Images,
                DateTime = post.ModifiedOn,
                Username = user.UserName,
                FullName = post.AppUser.FirstName + " " + post.AppUser.LastName,
                Likes = post.PostLikes.Count,
                Comments = post.PostComments.OrderByDescending(x => x.CommentedOn).Select(comment => new CommentViewModel
                {
                    Id = comment.Id,
                    Text = comment.Comment,
                    CommentedOn = comment.CommentedOn.ToString("MMM dd, yyyy HH:mm"),
                    Username = post.AppUser.FirstName + " " + post.AppUser.LastName,
                }).ToList(),
                UserLiked = post.PostLikes.Any(like => like.AppUserId == post.AppUserId && like.PostId == post.Id)
            }).ToList();

            return View(postViewModel);
        }

        [HttpGet]
        public IActionResult GetPostData(int postId)
        {
            var post = _context.Posts.FirstOrDefault(p => p.Id == postId);

            if (post == null)
            {
                return NotFound();
            }

            var imagePath = "/images/" + post.Images;

            var postDetails = new
            {
                ImagePath = imagePath,
                Description = post.Description
            };

            return Json(postDetails);
        }


        [HttpPost]
        public async Task<IActionResult> UploadPost([FromForm] PostViewModel postViewModel)
        {
            var guidFileName = $"{Guid.NewGuid()}{Path.GetExtension(postViewModel.Image.FileName)}";
            var filePath = Path.Combine(_environment.ContentRootPath, "wwwroot", "images", guidFileName);

            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await postViewModel.Image.CopyToAsync(stream);
            }
            var post = new Post
            {
                Description = postViewModel.Description,
                Images = guidFileName,
                AppUserId = await GetCurrentUserId(User),
                CreatedOn = DateTime.Now,
                ModifiedOn = DateTime.Now
            };

            await _context.Posts.AddAsync(post);
            await _context.SaveChangesAsync();
            return Ok();
        }

        [HttpPost]
        public async Task<IActionResult> PostComment(int postId, string commentText)
        {
            var appUserId = await GetCurrentUserId(User);
            var comment = new PostComment
            {
                AppUserId = appUserId,
                PostId = postId,
                Comment = commentText,
                CommentedOn = DateTime.Now
            };

            await _context.PostComments.AddAsync(comment);
            await _context.SaveChangesAsync();

            return Json(new { success = true });
        }

        [HttpGet]
        public async Task<IActionResult> GetComments(int postId)
        {
            var comments = await _context.PostComments
                .Where(x => x.PostId == postId)
                .OrderByDescending(x => x.CommentedOn)
                .ToListAsync();

            var currentUser = await GetCurrentUser(User);

            var commentViewModels = comments.Select(x => new CommentViewModel
            {
                Id = x.Id,
                Text = x.Comment,
                CommentedOn = x.CommentedOn.ToString("MMM dd, yyyy HH:mm"),
                Username = currentUser.FirstName + " " + currentUser.LastName,
            }).ToList();

            return Json(commentViewModels);
        }

        [HttpPost]
        public async Task<IActionResult> LikePost(int postId)
        {
            var like = new PostLike
            {
                AppUserId = await GetCurrentUserId(User),
                PostId = postId
            };

            await _context.PostLikes.AddAsync(like);
            await _context.SaveChangesAsync();
            var likesCount = await _context.PostLikes.Where(x => x.PostId == postId).CountAsync();
            return Json(new { success = true, likesCount = likesCount });
        }


        #region private helpers
        private async Task<int> GetCurrentUserId(ClaimsPrincipal user)
        {
            var appUser = await _userManager.GetUserAsync(user);
            return appUser.Id;
        }

        private async Task<AppUser> GetCurrentUser(ClaimsPrincipal user)
        {
            return await _userManager.GetUserAsync(user);
        }
        #endregion
    }
}